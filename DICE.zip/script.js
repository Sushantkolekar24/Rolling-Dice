


//    dice images

let image = [ "1.png" , "2.png", "3.png", "4.png", "5.png", "6.png"] ; 

let dice = document.querySelectorAll("img") ;



// function

function roll(){ dice.forEach(function (die){ die.classList.add("shake") ; });

setTimeout(function(){dice.forEach(function(die){die.classList.remove("shake"); } );

let die1Value = Math.floor(Math.random()*6 );
let die2Value = Math.floor(Math.random()*6 );

console.log( die1Value, die2Value) ;

document.querySelector("#die-1").setAttribute("src", image[die1Value]) ;
document.querySelector("#die-2").setAttribute("src", image[die2Value]) ;

document.querySelector("#Total").innerHTML = "Your Roll Is " + (( die1Value + 1) + ( die2Value + 1 ))

}

,1500);}



